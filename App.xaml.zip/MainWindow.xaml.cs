﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MateraLab1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnOblicz_Click(object sender, RoutedEventArgs e)
        {
            double r, h, V;
            try
            {
               
                    r = Convert.ToDouble(txtPromień.Text);
                    h = Convert.ToDouble(txtWysokość.Text);
                if (r > 0 && h > 0)
                {
                    switch (cbxRodzajBryły.SelectedIndex)
                    {
                        case 0:
                            V = Math.PI * Math.Pow(r, 2) * h;
                           
                            break;
                            case 1:
                            V = 1D / 3.0 * Math.PI * Math.Pow(r, 2) * h;
                            break;
                            case 2:
                            V = 4.0 / 3 * Math.PI * Math.Pow(r, 3);
                            break;
                        default:throw new NotImplementedException();
                    }
                    lblObjętość.Content = $"Objętość wynosi: {V:F2}  m^3";
                }
                else
                {
                    MessageBox.Show("złe dane");
                }
            }
            catch(FormatException)
            {
                MessageBox.Show("złe dane");
            }

        }

        private void cbxRodzajBryły_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cbxRodzajBryły.SelectedIndex == 2)
                txtWysokość.Visibility = Visibility.Hidden;
            else txtWysokość.Visibility = Visibility.Visible;
        }
        void RysujLinie(double x1, double x2, double y1, double y2, double grubość=1,Brush pędzel=null)
        {if (pędzel == null)
                pędzel = Brushes.Red;
            var myLine = new Line();
            myLine.Stroke = pędzel;
            myLine.X1 = x1;
            myLine.X2 = x2;
            myLine.Y1 = y1;
            myLine.Y2 = y2;
            myLine.StrokeThickness = grubość;
            cvRysunek.Children.Add(myLine);
            
        }
        void CzyśćPłutno()
        {
            cvRysunek.Children.Clear();
        }
        void RysujWypełnionąElipsę(double x,double y,double wysokość,double szerokość,Brush pędzel )
        {
            Ellipse elips = new Ellipse();
            elips.Stroke = pędzel;
            elips.Width = szerokość;
            elips.Height = wysokość;
            elips.Fill = pędzel;
            cvRysunek.Children.Add(elips);
            Canvas.SetLeft(elips, x-szerokość);
            Canvas.SetTop(elips, y);
            
            
        }
        void RysujOkrąg(double x, double y, double wysokość, double szerokość, Brush pędzel)
        {
            Ellipse elips = new Ellipse();
            elips.Stroke = pędzel;
            elips.StrokeThickness = 10;
            elips.Width = szerokość;
            elips.Height = wysokość;
            cvRysunek.Children.Add(elips);
            Canvas.SetLeft(elips, x - szerokość);
            Canvas.SetTop(elips, y);
        }
        void RysujWypełnioneKoło(double x,double y,double proień,Brush pędzel)
        {
            RysujWypełnionąElipsę(x + proień, y - proień, proień * 2, proień * 2, pędzel);

        }
        void RysujKoło(double x, double y, double proień, Brush pędzel)
        {
            RysujOkrąg(x + proień, y - proień, proień * 2, proień * 2, pędzel);

        }

        private void btnRysuj_Click(object sender, RoutedEventArgs e)
        {
            CzyśćPłutno();
            RysujLinie(0,299,150,150,5,Brushes.Red);
          RysujLinie(x1:150,x2:150,y1:150,y2:299,grubość:5,pędzel:Brushes.Green);
        }

        private void btnRysuj3_Click(object sender, RoutedEventArgs e)
        {
            CzyśćPłutno();
            RysujSzpalerDrzew(69, 299, 90, 5);
        }
        void RysujSzpalerDrzew(double x,double y,double odległość,double liczba)
        {
            for(int i=0; i<liczba; i++) 
            {
                RysujDrzewo(x, y,100,50);
                x+= odległość;
            }
        }
        void RysujDrzewo(double x,double y,double długośćPnia,double promieńKorony)
        {
            RysujLinie(x, x, y, y - długośćPnia, 5, Brushes.Brown);
            RysujWypełnioneKoło(x,y-długośćPnia-promieńKorony,promieńKorony,Brushes.Green);
            RysujKoło(x, y - długośćPnia - promieńKorony, promieńKorony, Brushes.DarkGreen);
            
        }
    }
}
